// popup.js - 插件弹窗逻辑
document.addEventListener("DOMContentLoaded", function () {
  const selectAreaBtn = document.getElementById("selectArea");
  const statusDiv = document.getElementById("status");
  const toggleFiltersBtn = document.getElementById("toggleFilters");
  const filterConfig = document.getElementById("filterConfig");
  const filterList = document.getElementById("filterList");
  const addFilterBtn = document.getElementById("addFilter");
  const saveFiltersBtn = document.getElementById("saveFilters");

  let currentFilters = [];

  // 显示状态信息
  function showStatus(message, type = "info") {
    statusDiv.textContent = message;
    statusDiv.className = `status-message ${type}`;
    setTimeout(() => {
      statusDiv.textContent = "";
      statusDiv.className = "status-message";
    }, 3000);
  }

  // 选择内容区域
  selectAreaBtn.addEventListener("click", async () => {
    try {
      showStatus("请在页面上点击要选择的内容区域", "info");

      // 获取当前活动标签页
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      // 向内容脚本发送消息，开始区域选择模式
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "startAreaSelection",
      });

      if (response && response.success) {
        showStatus("区域选择模式已激活，点击页面元素进行选择", "success");
        // 关闭弹窗，让用户可以在页面上进行选择
        window.close();
      } else {
        showStatus("启动区域选择失败", "error");
      }
    } catch (error) {
      console.error("启动区域选择失败:", error);
      showStatus("启动区域选择失败: " + error.message, "error");
    }
  });

  // 过滤器管理功能
  async function loadFilters() {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "getContentFilters",
      });

      if (response && response.success) {
        currentFilters = response.data || [];
        renderFilterList();
      } else {
        showStatus("加载过滤器配置失败", "error");
      }
    } catch (error) {
      console.error("加载过滤器失败:", error);
      showStatus("加载过滤器失败: " + error.message, "error");
    }
  }

  function renderFilterList() {
    filterList.innerHTML = "";

    currentFilters.forEach((filter, index) => {
      const filterItem = document.createElement("div");
      filterItem.className = `filter-item ${!filter.enabled ? "disabled" : ""}`;
      filterItem.innerHTML = `
        <button class="delete-filter" data-index="${index}">×</button>
        <div class="filter-header">
          <span class="filter-name">${filter.name}</span>
          <div class="filter-toggle">
            <input type="checkbox" ${
              filter.enabled ? "checked" : ""
            } data-index="${index}">
            <span>启用</span>
          </div>
        </div>
        <div class="filter-pattern">
          <label>正则表达式模式:</label>
          <input type="text" value="${
            filter.pattern
          }" data-index="${index}" data-field="pattern" placeholder="例如: .*体验AI代码助手代码解读复制代码">
        </div>
        <div class="filter-replacement">
          <label>替换内容:</label>
          <input type="text" value="${
            filter.replacement
          }" data-index="${index}" data-field="replacement" placeholder="留空表示删除匹配的内容">
        </div>
      `;
      filterList.appendChild(filterItem);
    });

    // 添加事件监听器
    addFilterEventListeners();
  }

  function addFilterEventListeners() {
    // 删除过滤器
    filterList.querySelectorAll(".delete-filter").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const index = parseInt(e.target.dataset.index);
        currentFilters.splice(index, 1);
        renderFilterList();
      });
    });

    // 切换启用状态
    filterList
      .querySelectorAll('input[type="checkbox"]')
      .forEach((checkbox) => {
        checkbox.addEventListener("change", (e) => {
          const index = parseInt(e.target.dataset.index);
          currentFilters[index].enabled = e.target.checked;
          renderFilterList();
        });
      });

    // 更新字段值
    filterList.querySelectorAll('input[type="text"]').forEach((input) => {
      input.addEventListener("input", (e) => {
        const index = parseInt(e.target.dataset.index);
        const field = e.target.dataset.field;
        currentFilters[index][field] = e.target.value;
      });
    });
  }

  function addNewFilter() {
    const newFilter = {
      id: "filter-" + Date.now(),
      name: "新过滤器",
      pattern: "",
      replacement: "",
      enabled: true,
    };
    currentFilters.push(newFilter);
    renderFilterList();
  }

  async function saveFilters() {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "saveContentFilters",
        data: currentFilters,
      });

      if (response && response.success) {
        showStatus("过滤器配置已保存", "success");
      } else {
        showStatus("保存过滤器配置失败", "error");
      }
    } catch (error) {
      console.error("保存过滤器失败:", error);
      showStatus("保存过滤器失败: " + error.message, "error");
    }
  }

  // 事件监听器
  toggleFiltersBtn.addEventListener("click", () => {
    filterConfig.classList.toggle("hidden");
    if (!filterConfig.classList.contains("hidden")) {
      loadFilters();
    }
  });

  addFilterBtn.addEventListener("click", addNewFilter);
  saveFiltersBtn.addEventListener("click", saveFilters);

  // 初始化
  console.log("getContextCode 插件弹窗已加载");
});
