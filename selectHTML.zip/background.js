// background.js - 服务工作者脚本
chrome.runtime.onInstalled.addListener((details) => {
  console.log("getContextCode 插件已安装");

  // 创建右键菜单
  chrome.contextMenus.create({
    id: "selectArea",
    title: "选择内容区域",
    contexts: ["page"],
  });

  chrome.contextMenus.create({
    id: "clearSelectedArea",
    title: "清除选择区域",
    contexts: ["page"],
  });

  // 设置默认配置
  chrome.storage.sync.set({
    // 可以在这里添加区域选择相关的默认配置
  });
});

// 处理右键菜单点击
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "selectArea") {
    // 启动区域选择模式
    chrome.tabs
      .sendMessage(tab.id, {
        action: "startAreaSelection",
      })
      .catch((error) => {
        console.error("启动区域选择失败:", error);
      });
  } else if (info.menuItemId === "clearSelectedArea") {
    // 清除选择区域
    chrome.tabs
      .sendMessage(tab.id, {
        action: "clearSelectedArea",
      })
      .catch((error) => {
        console.error("清除选择区域失败:", error);
      });
  }
});

// 处理来自内容脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "saveSelectedArea") {
    // 保存选择的内容区域到存储
    chrome.storage.local
      .set({
        selectedArea: request.data,
        timestamp: Date.now(),
        url: sender.tab.url,
      })
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("保存失败:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // 保持消息通道开放
  }

  if (request.action === "getStoredArea") {
    // 获取存储的选择区域
    chrome.storage.local
      .get(["selectedArea", "timestamp", "url"])
      .then((result) => {
        sendResponse({
          success: true,
          data: result,
        });
      })
      .catch((error) => {
        console.error("获取存储数据失败:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  if (request.action === "clearStorage") {
    // 清除存储
    chrome.storage.local
      .clear()
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("清除存储失败:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// 监听标签页更新（可以在这里添加区域选择相关的自动功能）
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    console.log("页面加载完成:", tab.url);
    // 可以在这里添加区域选择相关的自动功能
  }
});

// 处理插件图标点击（如果没有弹出窗口）
chrome.action.onClicked.addListener((tab) => {
  // 如果manifest中没有设置popup，这里可以处理点击事件
  chrome.tabs
    .sendMessage(tab.id, {
      action: "startAreaSelection",
    })
    .catch((error) => {
      console.error("启动区域选择失败:", error);
    });
});

// 错误处理
chrome.runtime.onSuspend.addListener(() => {
  console.log("getContextCode 插件即将暂停");
});

// 处理存储变化
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "sync") {
    console.log("设置已更新:", changes);
  }
});
