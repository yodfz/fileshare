// content.js - 内容脚本
(function () {
  "use strict";

  let isAreaSelectionMode = false;
  let selectedElement = null;
  let areaSelectionOverlay = null;
  let boundEventHandlers = {};

  // 区域选择功能
  const AreaSelector = {
    startSelection() {
      if (isAreaSelectionMode) return;

      // 清理已选择的内容区域和上一次的高亮区域
      this.clearSelection();
      this.clearPreview();

      // 清理之前可能存在的成功提示弹窗
      const existingSuccessTooltips = document.querySelectorAll(
        ".getContextCode-selection-success"
      );
      existingSuccessTooltips.forEach((tooltip) => tooltip.remove());

      isAreaSelectionMode = true;
      document.body.style.cursor = "crosshair";

      // 创建选择提示覆盖层
      this.createOverlay();

      // 创建绑定的事件处理器
      boundEventHandlers.mouseOver = this.handleMouseOver.bind(this);
      boundEventHandlers.mouseOut = this.handleMouseOut.bind(this);
      boundEventHandlers.click = this.handleClick.bind(this);
      boundEventHandlers.keyDown = this.handleKeyDown.bind(this);

      // 添加鼠标移动监听
      document.addEventListener("mouseover", boundEventHandlers.mouseOver);
      document.addEventListener("mouseout", boundEventHandlers.mouseOut);
      document.addEventListener("click", boundEventHandlers.click);
      document.addEventListener("keydown", boundEventHandlers.keyDown);
    },

    createOverlay() {
      areaSelectionOverlay = document.createElement("div");
      areaSelectionOverlay.id = "getContextCode-selection-overlay";
      areaSelectionOverlay.innerHTML = `
        <div class="selection-tooltip">
          <span>🎯 点击选择内容区域</span>
          <span class="hint">按 ESC 取消选择</span>
        </div>
      `;
      areaSelectionOverlay.className = "getContextCode-area-selection-overlay";
      document.body.appendChild(areaSelectionOverlay);
    },

    handleMouseOver(event) {
      if (!isAreaSelectionMode) return;

      event.preventDefault();
      event.stopPropagation();

      // 移除之前的高亮
      AreaSelector.clearPreview();

      // 高亮当前元素
      const element = event.target;
      if (
        element &&
        element !== document.body &&
        element !== document.documentElement &&
        element !== areaSelectionOverlay
      ) {
        AreaSelector.previewElement(element);
      }
    },

    handleMouseOut(event) {
      if (!isAreaSelectionMode) return;
      // 不清除预览，让用户看到选择效果
    },

    handleClick(event) {
      if (!isAreaSelectionMode) return;

      event.preventDefault();
      event.stopPropagation();

      const element = event.target;
      if (
        element &&
        element !== document.body &&
        element !== document.documentElement &&
        element !== areaSelectionOverlay
      ) {
        AreaSelector.selectElement(element);
      }
    },

    handleKeyDown(event) {
      if (!isAreaSelectionMode) return;

      if (event.key === "Escape") {
        AreaSelector.cancelSelection();
      }
    },

    previewElement(element) {
      element.classList.add("getContextCode-preview");
    },

    clearPreview() {
      const previewElements = document.querySelectorAll(
        ".getContextCode-preview"
      );
      previewElements.forEach((el) =>
        el.classList.remove("getContextCode-preview")
      );
    },

    selectElement(element) {
      // 清理之前的选择
      AreaSelector.clearSelection();

      selectedElement = element;
      AreaSelector.clearPreview();

      // 添加选中状态
      element.classList.add("getContextCode-selected");

      // 显示选择成功提示
      AreaSelector.showSelectionSuccess(element);

      // 退出选择模式
      AreaSelector.endSelection();

      // 保存选择结果
      AreaSelector.saveSelectedArea(element);
    },

    showSelectionSuccess(element) {
      const tooltip = document.createElement("div");
      tooltip.className = "getContextCode-selection-success";
      tooltip.innerHTML = `
        <div class="success-message">
          <span>✅ 已选择内容区域</span>
          <div class="action-buttons">
            <button id="copyAsMarkdown" class="copy-btn">复制</button>
            <button id="clearSelection" class="clear-btn">清除选择</button>
          </div>
        </div>
      `;

      document.body.appendChild(tooltip);

      // 获取选中元素的位置信息
      const rect = element.getBoundingClientRect();
      const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
      const scrollY = window.pageYOffset || document.documentElement.scrollTop;

      // 将提示框定位到选中元素的右上角
      tooltip.style.position = "absolute";
      tooltip.style.top = rect.top + scrollY + "px";
      tooltip.style.left = rect.right + scrollX + 10 + "px"; // 右边距10px
      tooltip.style.transform = "none"; // 移除居中的transform

      // 添加复制按钮事件
      tooltip.querySelector("#copyAsMarkdown").addEventListener("click", () => {
        AreaSelector.copyAsMarkdown(element);
        // 复制后清除选中高亮
        AreaSelector.clearSelection();
        // 移除成功提示弹窗
        tooltip.remove();
      });

      // 添加清除按钮事件
      tooltip.querySelector("#clearSelection").addEventListener("click", () => {
        AreaSelector.clearSelection();
        tooltip.remove();
      });
    },

    async copyAsMarkdown(element) {
      try {
        const markdown = await AreaSelector.convertToMarkdown(element);

        // 使用现代的 Clipboard API
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard
            .writeText(markdown)
            .then(() => {
              AreaSelector.showCopySuccess(
                "已复制为Markdown格式（已应用内容过滤）"
              );
            })
            .catch(() => {
              AreaSelector.fallbackCopy(markdown);
            });
        } else {
          AreaSelector.fallbackCopy(markdown);
        }
      } catch (error) {
        console.error("复制失败:", error);
        AreaSelector.showCopySuccess("复制失败: " + error.message, "error");
      }
    },

    // 创建一个干净的元素副本，剔除CSS相关内容
    createCleanCopy(element) {
      const clone = element.cloneNode(true);

      // 移除所有style标签
      const styleElements = clone.querySelectorAll("style");
      styleElements.forEach((style) => style.remove());

      // 移除所有script标签
      const scriptElements = clone.querySelectorAll("script");
      scriptElements.forEach((script) => script.remove());

      // 递归移除所有元素的style属性和CSS相关属性
      function cleanElement(el) {
        if (el.nodeType === Node.ELEMENT_NODE) {
          // 移除style属性
          el.removeAttribute("style");
          // 移除class属性（可能包含CSS类）
          el.removeAttribute("class");
          // 移除其他可能的CSS相关属性
          el.removeAttribute("id");

          // 递归处理子元素
          Array.from(el.children).forEach((child) => cleanElement(child));
        }
      }

      cleanElement(clone);
      return clone;
    },

    // 内容过滤配置管理
    ContentFilter: {
      // 默认过滤规则
      defaultFilters: [
        {
          id: "ai-helper-text",
          name: "AI代码助手相关文本",
          pattern: ".*体验AI代码助手代码解读复制代码",
          replacement: "",
          enabled: true,
        },
      ],

      // 获取过滤配置
      async getFilterConfig() {
        try {
          const result = await chrome.storage.sync.get(["contentFilters"]);
          return result.contentFilters || this.defaultFilters;
        } catch (error) {
          console.warn("获取过滤配置失败，使用默认配置:", error);
          return this.defaultFilters;
        }
      },

      // 保存过滤配置
      async saveFilterConfig(filters) {
        try {
          await chrome.storage.sync.set({ contentFilters: filters });
          return true;
        } catch (error) {
          console.error("保存过滤配置失败:", error);
          return false;
        }
      },

      // 应用内容过滤
      applyFilters(text, filters = null) {
        if (!text) return text;

        const activeFilters = filters || this.defaultFilters;
        let filteredText = text;

        activeFilters.forEach((filter) => {
          if (filter.enabled && filter.pattern) {
            try {
              const regex = new RegExp(filter.pattern, "gi");
              filteredText = filteredText.replace(
                regex,
                filter.replacement || ""
              );
            } catch (error) {
              console.warn(`过滤规则应用失败 [${filter.name}]:`, error);
            }
          }
        });

        return filteredText.trim();
      },
    },

    // 获取纯文本内容，过滤掉CSS和脚本
    getCleanTextContent(node) {
      let text = "";

      function extractText(n) {
        if (n.nodeType === Node.TEXT_NODE) {
          text += n.textContent;
        } else if (n.nodeType === Node.ELEMENT_NODE) {
          const tagName = n.tagName.toLowerCase();
          // 跳过style和script标签
          if (tagName !== "style" && tagName !== "script") {
            Array.from(n.childNodes).forEach((child) => extractText(child));
          }
        }
      }

      extractText(node);
      return text.trim();
    },

    async convertToMarkdown(element) {
      let markdown = "";

      // 获取过滤配置
      const filters = await AreaSelector.ContentFilter.getFilterConfig();

      // 创建一个干净的元素副本，剔除所有CSS相关内容
      const cleanElement = AreaSelector.createCleanCopy(element);

      // 递归处理元素及其子元素
      function processNode(node, depth = 0) {
        if (node.nodeType === Node.TEXT_NODE) {
          const text = node.textContent.trim();
          if (text) {
            return text;
          }
          return "";
        }

        if (node.nodeType === Node.ELEMENT_NODE) {
          const tagName = node.tagName.toLowerCase();
          let result = "";

          // 跳过style和script标签
          if (tagName === "style" || tagName === "script") {
            return "";
          }

          switch (tagName) {
            case "h1":
              result = "# " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "h2":
              result = "## " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "h3":
              result = "### " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "h4":
              result =
                "#### " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "h5":
              result =
                "##### " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "h6":
              result =
                "###### " + AreaSelector.getCleanTextContent(node) + "\n\n";
              break;
            case "p":
              const pContent = Array.from(node.childNodes)
                .map((child) => processNode(child, depth))
                .join("");
              if (pContent.trim()) {
                result = pContent.trim() + "\n\n";
              }
              break;
            case "br":
              result = "\n";
              break;
            case "strong":
            case "b":
              result = "**" + AreaSelector.getCleanTextContent(node) + "**";
              break;
            case "em":
            case "i":
              result = "*" + AreaSelector.getCleanTextContent(node) + "*";
              break;
            case "code":
              if (
                node.parentNode &&
                node.parentNode.tagName.toLowerCase() === "pre"
              ) {
                // 代码块 - 尝试读取lang属性作为语言指示
                const lang =
                  node.getAttribute("lang") || node.getAttribute("class") || "";
                // 从class属性中提取语言信息（常见的语法高亮库格式）
                const classLang =
                  lang.match(/language-(\w+)/) || lang.match(/lang-(\w+)/);
                const language = classLang ? classLang[1] : lang || "";

                result =
                  "\n```" +
                  language +
                  "\n" +
                  AreaSelector.getCleanTextContent(node) +
                  "\n```\n\n";
              } else {
                // 行内代码
                result = "`" + AreaSelector.getCleanTextContent(node) + "`";
              }
              break;
            case "pre":
              if (node.querySelector("code")) {
                // 如果pre包含code，让code标签处理
                result = Array.from(node.childNodes)
                  .map((child) => processNode(child, depth))
                  .join("");
              } else {
                result =
                  "```\n" +
                  AreaSelector.getCleanTextContent(node) +
                  "\n```\n\n";
              }
              break;
            case "a":
              const href = node.getAttribute("href");
              if (href && !href.startsWith("javascript:")) {
                result =
                  "[" +
                  AreaSelector.getCleanTextContent(node) +
                  "](" +
                  href +
                  ")";
              } else {
                result = AreaSelector.getCleanTextContent(node);
              }
              break;
            case "img":
              const src = node.getAttribute("src");
              const alt = node.getAttribute("alt") || "";
              if (src && !src.startsWith("data:")) {
                result = "![" + alt + "](" + src + ")";
              }
              break;
            case "ul":
            case "ol":
              result =
                Array.from(node.children)
                  .map((li, index) => {
                    if (li.tagName.toLowerCase() === "li") {
                      const prefix = tagName === "ul" ? "- " : `${index + 1}. `;
                      return prefix + AreaSelector.getCleanTextContent(li);
                    }
                    return "";
                  })
                  .filter((item) => item.trim())
                  .join("\n") + "\n\n";
              break;
            case "li":
              // 由父元素处理
              result = AreaSelector.getCleanTextContent(node);
              break;
            case "blockquote":
              const lines = AreaSelector.getCleanTextContent(node).split("\n");
              result =
                lines
                  .map((line) => "> " + line.trim())
                  .filter((line) => line.length > 2)
                  .join("\n") + "\n\n";
              break;
            case "table":
              result = AreaSelector.convertTableToMarkdown(node);
              break;
            case "div":
            case "span":
            case "section":
            case "article":
            case "main":
            case "header":
            case "footer":
            case "nav":
            default:
              // 处理子节点
              result = Array.from(node.childNodes)
                .map((child) => processNode(child, depth))
                .join("");
              break;
          }

          return result;
        }

        return "";
      }

      markdown = processNode(cleanElement);

      // 清理多余的空行和空白字符
      markdown = markdown
        .replace(/\n{3,}/g, "\n\n") // 多个换行符合并为两个
        .replace(/[ \t]+/g, " ") // 多个空格合并为一个
        .replace(/[ \t]*\n/g, "\n") // 行末空格
        .trim();

      // 应用内容过滤
      markdown = AreaSelector.ContentFilter.applyFilters(markdown, filters);

      return markdown;
    },

    convertTableToMarkdown(table) {
      let markdown = "";
      const rows = table.querySelectorAll("tr");

      if (rows.length === 0) return "";

      rows.forEach((row, rowIndex) => {
        const cells = row.querySelectorAll("th, td");
        const cellTexts = Array.from(cells).map((cell) =>
          AreaSelector.getCleanTextContent(cell)
        );
        markdown += "| " + cellTexts.join(" | ") + " |\n";

        // 添加表头分隔符
        if (rowIndex === 0 && row.querySelectorAll("th").length > 0) {
          const separator = Array.from(cells)
            .map(() => "---")
            .join(" | ");
          markdown += "| " + separator + " |\n";
        }
      });

      return markdown + "\n";
    },

    fallbackCopy(text) {
      // 降级方案：创建临时文本区域
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      textArea.style.left = "-999999px";
      textArea.style.top = "-999999px";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      try {
        const successful = document.execCommand("copy");
        if (successful) {
          AreaSelector.showCopySuccess("已复制为Markdown格式");
        } else {
          AreaSelector.showCopySuccess("复制失败，请手动复制", "error");
        }
      } catch (err) {
        console.error("降级复制失败:", err);
        AreaSelector.showCopySuccess("复制失败: " + err.message, "error");
      } finally {
        document.body.removeChild(textArea);
      }
    },

    showCopySuccess(message, type = "success") {
      const toast = document.createElement("div");
      toast.className = "getContextCode-copy-toast";
      toast.innerHTML = `
        <div class="toast-content ${type}">
          <span>${type === "success" ? "✅" : "❌"} ${message}</span>
        </div>
      `;

      document.body.appendChild(toast);

      // 2秒后自动移除
      setTimeout(() => {
        if (toast.parentNode) {
          toast.remove();
        }
      }, 2000);
    },

    clearSelection() {
      // 清理所有已选择的元素
      const selectedElements = document.querySelectorAll(
        ".getContextCode-selected"
      );
      selectedElements.forEach((el) =>
        el.classList.remove("getContextCode-selected")
      );

      // 重置选择状态
      selectedElement = null;
    },

    saveSelectedArea(element) {
      const areaData = {
        tagName: element.tagName,
        className: element.className,
        id: element.id,
        textContent: element.textContent.substring(0, 200), // 限制长度
        innerHTML: element.innerHTML.substring(0, 500), // 限制长度
        rect: element.getBoundingClientRect(),
        timestamp: Date.now(),
      };

      // 存储到本地存储
      chrome.storage.local.set({
        selectedArea: areaData,
      });

      console.log("已保存选择的内容区域:", areaData);
    },

    cancelSelection() {
      AreaSelector.clearPreview();
      AreaSelector.endSelection();
    },

    endSelection() {
      isAreaSelectionMode = false;
      document.body.style.cursor = "";

      // 移除事件监听
      if (boundEventHandlers.mouseOver) {
        document.removeEventListener("mouseover", boundEventHandlers.mouseOver);
        document.removeEventListener("mouseout", boundEventHandlers.mouseOut);
        document.removeEventListener("click", boundEventHandlers.click);
        document.removeEventListener("keydown", boundEventHandlers.keyDown);

        // 清空事件处理器引用
        boundEventHandlers = {};
      }

      // 移除覆盖层
      if (areaSelectionOverlay) {
        areaSelectionOverlay.remove();
        areaSelectionOverlay = null;
      }
    },
  };

  // 消息处理
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    try {
      switch (request.action) {
        case "startAreaSelection":
          AreaSelector.startSelection();
          sendResponse({
            success: true,
            message: "区域选择模式已启动",
          });
          break;

        case "clearSelectedArea":
          AreaSelector.clearSelection();
          sendResponse({
            success: true,
            message: "已清除选择的内容区域",
          });
          break;

        case "getContentFilters":
          AreaSelector.ContentFilter.getFilterConfig()
            .then((filters) => {
              sendResponse({
                success: true,
                data: filters,
              });
            })
            .catch((error) => {
              sendResponse({
                success: false,
                error: error.message,
              });
            });
          return true; // 保持异步响应通道开放

        case "saveContentFilters":
          AreaSelector.ContentFilter.saveFilterConfig(request.data)
            .then((success) => {
              sendResponse({
                success: success,
                message: success ? "过滤配置已保存" : "保存过滤配置失败",
              });
            })
            .catch((error) => {
              sendResponse({
                success: false,
                error: error.message,
              });
            });
          return true; // 保持异步响应通道开放

        default:
          sendResponse({
            success: false,
            message: "未知操作",
          });
      }
    } catch (error) {
      console.error("Content script error:", error);
      sendResponse({
        success: false,
        error: error.message,
      });
    }

    return true; // 保持消息通道开放
  });

  // 页面加载完成后的初始化
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }

  function initialize() {
    console.log("getContextCode 内容脚本已加载");

    // 注入CSS样式
    injectStyles();

    // 添加全局ESC键监听器，用于在选择完成后取消选择
    addGlobalEscapeListener();
  }

  // 添加全局ESC键监听器
  function addGlobalEscapeListener() {
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        // 如果有选中的元素，清除选择
        if (selectedElement) {
          AreaSelector.clearSelection();

          // 移除成功提示弹窗
          const successTooltips = document.querySelectorAll(
            ".getContextCode-selection-success"
          );
          successTooltips.forEach((tooltip) => tooltip.remove());
        }

        // 如果正在选择模式，取消选择模式
        if (isAreaSelectionMode) {
          AreaSelector.cancelSelection();
        }
      }
    });
  }

  function injectStyles() {
    // 检查是否已经注入了样式
    if (document.getElementById("getContextCode-styles")) {
      return;
    }

    // 创建样式元素
    const style = document.createElement("style");
    style.id = "getContextCode-styles";
    style.textContent = `
      /* 区域选择相关样式 */
      .getContextCode-area-selection-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.1);
        z-index: 999999;
        pointer-events: none;
      }

      .getContextCode-area-selection-overlay .selection-tooltip {
        position: fixed;
        top: 20px;
        right: 20px;
        background: #667eea;
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        font-size: 14px;
        font-weight: 500;
        z-index: 1000000;
        pointer-events: none;
      }

      .getContextCode-area-selection-overlay .selection-tooltip .hint {
        display: block;
        font-size: 12px;
        opacity: 0.8;
        margin-top: 4px;
      }

      .getContextCode-preview {
        outline: 2px solid #ffdb1d !important;
        background-color: #efffd8 !important;
        transition: all 0.2s ease !important;
      }

      .getContextCode-selected {
        outline: 3px solid #ffdb1d !important;
        position: relative !important;
        background-color: #efffd8 !important;
      }


      .getContextCode-selection-success {
        position: absolute;
        background: white;
        border: 2px solid #28a745;
        border-radius: 12px;
        padding: 15px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
        z-index: 1000000;
        animation: getContextCode-fadeIn 0.3s ease-out;
        min-width: 200px;
      }

      .getContextCode-selection-success .success-message {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        font-size: 16px;
        color: #333;
      }

      .getContextCode-selection-success .action-buttons {
        display: flex;
        gap: 8px;
      }

      .getContextCode-selection-success .copy-btn {
        background: #28a745;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        font-weight: 500;
        transition: all 0.2s;
      }

      .getContextCode-selection-success .copy-btn:hover {
        background: #218838;
        transform: translateY(-1px);
      }

      .getContextCode-selection-success .clear-btn {
        background: #dc3545;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        font-weight: 500;
        transition: all 0.2s;
      }

      .getContextCode-selection-success .clear-btn:hover {
        background: #c82333;
        transform: translateY(-1px);
      }

      /* 复制成功提示样式 */
      .getContextCode-copy-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000001;
        animation: getContextCode-slideIn 0.3s ease-out;
      }

      .getContextCode-copy-toast .toast-content {
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      }

      .getContextCode-copy-toast .toast-content.success {
        background: #28a745;
        color: white;
      }

      .getContextCode-copy-toast .toast-content.error {
        background: #dc3545;
        color: white;
      }

      @keyframes getContextCode-slideIn {
        from {
          opacity: 0;
          transform: translateX(100%);
        }
        to {
          opacity: 1;
          transform: translateX(0);
        }
      }

      /* 动画效果 */
      @keyframes getContextCode-fadeIn {
        from {
          opacity: 0;
          transform: translate(-50%, -60px);
        }
        to {
          opacity: 1;
          transform: translate(-50%, -50%);
        }
      }

      /* 响应式设计 */
      @media (max-width: 768px) {
        .getContextCode-area-selection-overlay .selection-tooltip {
          top: 10px;
          right: 10px;
          padding: 8px 12px;
          font-size: 12px;
        }
        
        .getContextCode-selected::before {
          font-size: 10px;
          padding: 2px 6px;
        }
      }
    `;

    // 将样式添加到页面头部
    document.head.appendChild(style);
    console.log("getContextCode CSS样式已注入");
  }

  // 导出到全局作用域（用于调试）
  window.getContextCode = {
    areaSelector: AreaSelector,
    isAreaSelectionMode: () => isAreaSelectionMode,
    selectedElement: () => selectedElement,
  };
})();
